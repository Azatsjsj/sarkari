<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <meta name="description" content="@yield('meta_description', 'Latest Sarkari Result updates, government jobs, admit cards, results and answer keys. Find all upcoming and ongoing recruitment notifications.')">
    <meta name="keywords" content="@yield('meta_keywords', 'sarkari result, government jobs, latest jobs, admit card, results, recruitment')">
    <meta name="author" content="Sarkari Result">
    <meta name="robots" content="index, follow">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="canonical" href="{{ url()->current() }}" />

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="@yield('title', 'Sarkari Result - Latest Government Jobs and Results')">
    <meta property="og:description" content="@yield('meta_description', 'Latest Sarkari Result updates, government jobs, admit cards, results and answer keys.')">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:image" content="{{ asset('images/og-image.jpg') }}">
    <meta property="og:site_name" content="Sarkari Result">

    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="@yield('title', 'Sarkari Result - Latest Government Jobs and Results')">
    <meta name="twitter:description" content="@yield('meta_description', 'Latest Sarkari Result updates, government jobs, admit cards, results and answer keys.')">
    <meta name="twitter:image" content="{{ asset('images/og-image.jpg') }}">

    <!-- Theme Color for Mobile Browsers -->
    <meta name="theme-color" content="#dc3545">
    <meta name="color-scheme" content="light">

    <title>@yield('title', 'Sarkari Result - Latest Government Jobs and Results')</title>
   
    <!-- Favicon - Optimized paths -->
    <link rel="icon" type="image/png" href="{{ asset('images/favicon-96x96.png') }}" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="{{ asset('images/favicon.svg') }}" />
    <link rel="shortcut icon" href="{{ asset('images/favicon.ico') }}" />
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('images/apple-touch-icon.png') }}" />
    <!---link rel="manifest" href="{{ asset('images/site.webmanifest') }}" /--->

    <!-- Preconnect for Critical Third-Party Domains -->
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>

    <!-- Bootstrap CSS (Critical) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Preload Critical Font Awesome Icons -->
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/webfonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin>
    
    <!-- Font Awesome - Non-blocking -->
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    </noscript>

    <!-- Google Fonts - Inter (Non-blocking) -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Main Stylesheet (Non-blocking with preload) -->
    <link rel="preload" href="{{ asset('css/style.css') }}" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    </noscript>
    
    <!-- Inline Critical CSS for Above-the-Fold Content -->
    <style>
        /* Critical CSS for initial render */
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.04);
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            line-height: 1;
        }
        .logo .sarkari { color: #e65100; }
        .logo .result { color: #2e7d32; }
        .logo .mobi { color: #0d47a1; font-size: 22px; }
        .loading-spinner {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.75);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }
        .loading-spinner.show { display: flex; }
        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid rgba(255,255,255,0.2);
            border-top-color: #dc3545;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .back-to-top.show {
            opacity: 1;
            visibility: visible;
        }
    </style>

    <!-- Google AdSense - Deferred -->
    <meta name="google-site-verification" content="4bSR8xyCVu86jE3jpVq_WTRoRXObxfJIOerEMqKNiBI" />
    
    <!-- Dynamic JSON-LD Structured Data -->
    @php
        $structuredData = '';
        if (class_exists('App\Services\StructuredDataGenerator')) {
            try {
                $structuredData = App\Services\StructuredDataGenerator::generate($pageType ?? 'home', [
                    'site_name' => 'SarkariResult.Mobi',
                    'site_url' => config('app.url'),
                    'page_title' => $pageTitle ?? '',
                    'page_description' => $pageDescription ?? '',
                    'date_modified' => now()->toIso8601String()
                ]);
                echo $structuredData;
            } catch (Exception $e) {
                if (config('app.debug')) {
                    echo '<!-- Structured Data Error: ' . e($e->getMessage()) . ' -->';
                }
            }
        }
    @endphp
    
    @stack('jsonld')
    @stack('styles')
</head>
<body>
    <!-- Loading Spinner -->
    <div class="loading-spinner" id="loadingSpinner" role="status" aria-live="polite">
        <div class="spinner"></div>
        <span class="sr-only">Loading...</span>
    </div>


    <!-- Skip to Main Content Link (Accessibility) -->
    <a href="#main-content" class="skip-to-main" style="position: absolute; top: -40px; left: 0; background: #dc3545; color: white; padding: 8px 16px; text-decoration: none; z-index: 10000;">
        Skip to main content
    </a>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-lg" aria-label="Main navigation">
        <div class="container">
            <!-- Logo -->
            <a class="navbar-brand d-flex align-items-center" href="{{ route('home') }}" aria-label="Sarkari Result Home">
                <div class="logo">
                    <span class="sarkari" aria-hidden="true">Sarkari</span>
                    <span class="result" aria-hidden="true">Result</span>
                    <span class="mobi" aria-hidden="true">.mobi</span>
                </div>
            </a>
            
            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Collapsible Content -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}" aria-current="{{ request()->routeIs('home') ? 'page' : 'false' }}">
                            <i class="fas fa-home me-1" aria-hidden="true"></i>Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('jobs*') ? 'active' : '' }}" href="{{ route('jobs') }}">
                            <i class="fas fa-briefcase me-1" aria-hidden="true"></i>Latest Jobs
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('results*') ? 'active' : '' }}" href="{{ route('results') }}">
                            <i class="fas fa-chart-bar me-1" aria-hidden="true"></i>Results
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('admit-cards*') ? 'active' : '' }}" href="{{ route('admit-cards') }}">
                            <i class="fas fa-ticket-alt me-1" aria-hidden="true"></i>Admit Cards
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('answer-keys*') ? 'active' : '' }}" href="{{ route('answer-keys') }}">
                            <i class="fas fa-key me-1" aria-hidden="true"></i>Answer Keys
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('documents*') ? 'active' : '' }}" href="{{ route('documents.index') }}">
                            <i class="fas fa-file-alt me-1" aria-hidden="true"></i>Notices
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle {{ request()->routeIs('category*') ? 'active' : '' }}" 
                           href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-list me-1" aria-hidden="true"></i>Categories
                        </a>
                        <ul class="dropdown-menu" aria-label="Job categories">
                            @php
                                $categories = collect();
                                if (class_exists(\App\Models\Category::class)) {
                                    try {
                                        $categories = \App\Models\Category::where('is_active', true)
                                            ->withCount('jobs')
                                            ->latest()
                                            ->take(10)
                                            ->get();
                                    } catch (\Throwable $e) {
                                        $categories = collect();
                                    }
                                }
                            @endphp
                            @forelse($categories as $category)
                                <li>
                                    <a class="dropdown-item" href="{{ route('category', $category->slug) }}">
                                        <i class="fas fa-folder me-2 text-primary" aria-hidden="true"></i>
                                        {{ $category->name }}
                                        <span class="badge bg-primary rounded-pill float-end">{{ $category->jobs_count }}</span>
                                    </a>
                                </li>
                            @empty
                                <li><a class="dropdown-item text-muted" href="#"><i class="fas fa-folder me-2" aria-hidden="true"></i>No categories available</a></li>
                            @endforelse
                            @if($categories && $categories->count() > 0)
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-primary fw-semibold" href="{{ route('jobs') }}">
                                        <i class="fas fa-eye me-2" aria-hidden="true"></i>View All Categories
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </li>
                </ul>
                
                <!-- Search Form -->
                <form action="{{ route('jobs') }}" method="GET" class="search-form me-3" role="search" aria-label="Site search">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search jobs, results..." 
                               value="{{ request('search') }}"
                               aria-label="Search jobs and results"
                               autocomplete="off">
                        <button class="btn" type="submit" aria-label="Submit search">
                            <i class="fas fa-search" aria-hidden="true"></i>
                        </button>
                    </div>
                </form>

                <!-- Admin/Auth Links -->
                <ul class="navbar-nav">
                    @auth
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" 
                               aria-expanded="false" aria-label="Admin menu">
                                <i class="fas fa-user-shield me-1" aria-hidden="true"></i>Admin
                                <span class="notification-badge" aria-label="3 notifications">3</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="{{ route('admin.dashboard') }}">
                                        <i class="fas fa-tachometer-alt me-2" aria-hidden="true"></i>Dashboard
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="{{ route('admin.jobs.index') }}">
                                        <i class="fas fa-briefcase me-2" aria-hidden="true"></i>Manage Jobs
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="{{ route('admin.results.index') }}">
                                        <i class="fas fa-chart-bar me-2" aria-hidden="true"></i>Manage Results
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="{{ route('admin.admit-cards.index') }}">
                                        <i class="fas fa-ticket-alt me-2" aria-hidden="true"></i>Manage Admit Cards
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="{{ route('logout') }}" class="d-inline">
                                        @csrf
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="fas fa-sign-out-alt me-2" aria-hidden="true"></i>Logout
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @else
                        <li class="nav-item">
                            <a href="{{ route('login') }}" class="btn btn-outline-light btn-sm">
                                <i class="fas fa-sign-in-alt me-1" aria-hidden="true"></i>Login
                            </a>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main id="main-content" tabindex="-1">
        @yield('content')
    </main>

    <!-- Disclaimer Notice -->
    <div class="container">
        <div class="disclaimer">
            <i class="fas fa-exclamation-triangle me-2" aria-hidden="true"></i> 
            <strong>Disclaimer:</strong> SarkariResult.mobi is not affiliated with any Government Organization. This is a private website that provides information about government jobs, results, and admit cards for informational purposes only. All the information provided on this website is collected from various official sources. We recommend visitors to verify all details from the official government websites before taking any action. We are not responsible for any loss or inconvenience caused by the use of this information.
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-light py-5" role="contentinfo">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-brand mb-3">
                        <h4 class="text-warning mb-2">
                            <i class="fas fa-university me-2" aria-hidden="true"></i>Sarkari Result
                        </h4>
                        <p class="text-light opacity-75">
                            Your trusted partner for government job notifications, exam results, admit cards, 
                            and all Sarkari Result updates in one place.
                        </p>
                    </div>
                    <div class="social-links" aria-label="Social media links">
                        <a href="#" class="text-light me-2" aria-label="Facebook" rel="noopener noreferrer" target="_blank">
                            <i class="fab fa-facebook-f fa-lg" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="text-light me-2" aria-label="Twitter" rel="noopener noreferrer" target="_blank">
                            <i class="fab fa-twitter fa-lg" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="text-light me-2" aria-label="LinkedIn" rel="noopener noreferrer" target="_blank">
                            <i class="fab fa-linkedin-in fa-lg" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="text-light" aria-label="YouTube" rel="noopener noreferrer" target="_blank">
                            <i class="fab fa-youtube fa-lg" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="{{ route('home') }}"><i class="fas fa-arrow-right me-2" aria-hidden="true"></i>Home</a></li>
                        <li><a href="{{ route('jobs') }}"><i class="fas fa-arrow-right me-2" aria-hidden="true"></i>Latest Jobs</a></li>
                        <li><a href="{{ route('results') }}"><i class="fas fa-arrow-right me-2" aria-hidden="true"></i>Results</a></li>
                        <li><a href="{{ route('admit-cards') }}"><i class="fas fa-arrow-right me-2" aria-hidden="true"></i>Admit Cards</a></li>
                        <li><a href="{{ route('answer-keys') }}"><i class="fas fa-arrow-right me-2" aria-hidden="true"></i>Answer Keys</a></li>
                        <li><a href="{{ route('documents.index') }}"><i class="fas fa-arrow-right me-2" aria-hidden="true"></i>Notice</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <h5>Popular Categories</h5>
                    <ul class="list-unstyled">
                        @if(isset($categories) && $categories->count() > 0)
                            @foreach($categories->take(5) as $category)
                                <li>
                                    <a href="{{ route('category', $category->slug) }}">
                                        <i class="fas fa-folder me-2" aria-hidden="true"></i>{{ $category->name }}
                                    </a>
                                </li>
                            @endforeach
                        @else
                            <li><span class="text-light opacity-75">No categories available</span></li>
                        @endif
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li>
                            <i class="fas fa-envelope me-2" aria-hidden="true"></i>
                            <a href="mailto:info@sarkariresult.mobi" class="text-light opacity-75">info@sarkariresult.mobi</a>
                        </li>
                        <li>
                            <i class="fas fa-phone me-2" aria-hidden="true"></i>
                            <a href="tel:+918889322227" class="text-light opacity-75">+91-8889322227</a>
                        </li>
                        <li>
                            <i class="fas fa-map-marker-alt me-2" aria-hidden="true"></i>
                            <span class="text-light opacity-75">New Delhi, India</span>
                        </li>
                        <li>
                            <i class="fas fa-clock me-2" aria-hidden="true"></i>
                            <span class="text-light opacity-75">Mon - Fri: 9:00 - 18:00</span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <hr class="my-4 opacity-25">
            
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0 text-light opacity-75">
                        &copy; {{ date('Y') }} Sarkari Result. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="footer-links">
                        <a href="/privacy-policy" class="text-light opacity-75 me-3">Privacy Policy</a>
                        <a href="/terms-of-service" class="text-light opacity-75 me-3">Terms of Service</a>
                        <a href="/disclaimer" class="text-light opacity-75">Disclaimer</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="backToTop" aria-label="Back to top" title="Scroll back to top">
        <i class="fas fa-chevron-up" aria-hidden="true"></i>
    </button>

    <!-- JavaScript (Deferred for Performance) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" defer></script>
    <script src="{{ asset('js/app.js') }}" defer></script>
    
    <!-- Inline Script for Critical Functionality (No external dependencies) -->
    <script>
        (function() {
            'use strict';
            
            // Back to Top Button
            const backToTop = document.getElementById('backToTop');
            if (backToTop) {
                window.addEventListener('scroll', function() {
                    if (window.pageYOffset > 300) {
                        backToTop.classList.add('show');
                    } else {
                        backToTop.classList.remove('show');
                    }
                });
                backToTop.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                });
            }
            
            // Skip to main content handling
            const skipLink = document.querySelector('.skip-to-main');
            const mainContent = document.getElementById('main-content');
            if (skipLink && mainContent) {
                skipLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    mainContent.focus();
                });
            }
            
            // Add scroll class to navbar on scroll
            const navbar = document.querySelector('.navbar');
            if (navbar) {
                window.addEventListener('scroll', function() {
                    if (window.scrollY > 10) {
                        navbar.classList.add('scrolled');
                    } else {
                        navbar.classList.remove('scrolled');
                    }
                });
            }
        })();
    </script>
    
    @stack('scripts')
</body>
</html>