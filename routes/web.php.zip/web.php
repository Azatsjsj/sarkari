<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\JobController;
use App\Http\Controllers\ResultController;
use App\Http\Controllers\AdmitCardController;
use App\Http\Controllers\AnswerKeyController;
use App\Http\Controllers\AdmissionController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\UniversityController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\DocumentController;

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\JobController as AdminJobController;
use App\Http\Controllers\Admin\ResultController as AdminResultController;
use App\Http\Controllers\Admin\AdmitCardController as AdminAdmitCardController;
use App\Http\Controllers\Admin\AnswerKeyController as AdminAnswerKeyController;
use App\Http\Controllers\Admin\AdmissionController as AdminAdmissionController;
use App\Http\Controllers\Admin\UniversityController as AdminUniversityController;
use App\Http\Controllers\Admin\CourseController;
use App\Http\Controllers\Admin\AdminDocumentController;

use Illuminate\Support\Facades\Auth;

// ----------------------------
// Frontend Routes
// ----------------------------

Route::get('/', [HomeController::class, 'index'])->name('home');

// Privacy and legal pages
Route::get('/privacy-policy', [PageController::class, 'privacyPolicy'])->name('privacy.policy');
Route::get('/terms-of-service', [PageController::class, 'termsOfService'])->name('terms.service');
Route::get('/disclaimer', [PageController::class, 'disclaimer'])->name('disclaimer');

Route::prefix('sitemap')->name('sitemap.')->group(function () {
    Route::get('/', [SitemapController::class, 'index'])->name('index');
    Route::get('/pages.xml', [SitemapController::class, 'pages'])->name('pages');
    Route::get('/jobs.xml', [SitemapController::class, 'jobs'])->name('jobs'); // Full name: 'sitemap.jobs'
    Route::get('/categories.xml', [SitemapController::class, 'categories'])->name('categories'); // 'sitemap.categories'
    Route::get('/results.xml', [SitemapController::class, 'results'])->name('results'); // 'sitemap.results'
    Route::get('/admit-cards.xml', [SitemapController::class, 'admitCards'])->name('admit-cards'); // 'sitemap.admit-cards'
    Route::get('/answer-keys.xml', [SitemapController::class, 'answerKeys'])->name('answer-keys'); // 'sitemap.answer-keys'
    Route::get('/documents.xml', [SitemapController::class, 'documents'])->name('documents'); // 'sitemap.documents'
    Route::get('/admissions.xml', [SitemapController::class, 'admissions'])->name('admissions'); // 'sitemap.admissions'
   // Route::get('/universities.xml', [SitemapController::class, 'universities'])->name('universities'); // 'sitemap.universities'
    Route::get('/courses.xml', [SitemapController::class, 'courses'])->name('courses'); // 'sitemap.courses'
    
    // Admin route to generate all sitemaps
    Route::post('/generate-all', [SitemapController::class, 'generateAll'])
        ->name('generate-all')
        ->middleware('auth');
});

Route::prefix('admit-cards')->name('admit-cards.')->group(function () {
    Route::get('/search', [AdmitCardController::class, 'search'])->name('search');
    Route::get('/job/{jobSlug}', [AdmitCardController::class, 'byJob'])->name('by-job');
    Route::post('/{id}/increment-download', [AdmitCardController::class, 'incrementDownload'])->name('increment-download');
    Route::post('/{id}/increment-view', [AdmitCardController::class, 'incrementView'])->name('increment-view');
});
Route::get('/admit-cards', [HomeController::class, 'admitCardsIndex'])->name('admit-cards');
Route::get('/admit-card/{admitCard:slug}', [HomeController::class, 'showAdmitCard'])->name('admit-card.show');

// Answer Key Routes - SPECIFIC routes FIRST
Route::prefix('answer-keys')->name('answer-keys.')->group(function () {
    Route::get('/search', [AnswerKeyController::class, 'search'])->name('search');
    Route::get('/job/{jobSlug}', [AnswerKeyController::class, 'byJob'])->name('by-job');
    Route::get('/{id}/download', [AnswerKeyController::class, 'download'])->name('download');
    Route::post('/track-download', [AnswerKeyController::class, 'trackDownload'])->name('track-download');
});
Route::get('/answer-keys', [HomeController::class, 'answerKeysIndex'])->name('answer-keys');
Route::get('/answer-key/{answerKey:slug}', [HomeController::class, 'showAnswerKey'])->name('answer-key.show');

// Admission Routes - SPECIFIC routes FIRST
Route::prefix('admissions')->name('admissions.')->group(function () {
    Route::get('/featured', [AdmissionController::class, 'featured'])->name('featured');
    Route::get('/expired', [AdmissionController::class, 'expired'])->name('expired');
});
Route::get('/admissions', [HomeController::class, 'admissionsIndex'])->name('admissions');
Route::get('/admissions/{admission:slug}', [HomeController::class, 'showAdmission'])->name('admission.show');

// University and Course Routes
Route::get('/universities', [UniversityController::class, 'index'])->name('universities.index');
Route::get('/universities/featured', [UniversityController::class, 'featured'])->name('universities.featured');
Route::get('/university/{university:slug}', [AdmissionController::class, 'university'])->name('admission.university');
Route::get('/course/{course:slug}', [AdmissionController::class, 'course'])->name('admission.course');

// Frontend Document Routes
Route::prefix('documents')->name('documents.')->group(function () {
    Route::get('/', [DocumentController::class, 'index'])->name('index');
    Route::get('/notices', [DocumentController::class, 'notices'])->name('notices');
    Route::get('/certificates', [DocumentController::class, 'certificates'])->name('certificates');
    Route::get('/verify', [DocumentController::class, 'verifyForm'])->name('verify-form');
    Route::post('/verify', [DocumentController::class, 'verifyCertificate'])->name('verify');
    Route::get('/{document:slug}', [DocumentController::class, 'show'])->name('show');
    Route::get('/{document:slug}/download', [DocumentController::class, 'download'])->name('download');
});

// ----------------------------
// Admin Routes
// ----------------------------

Route::prefix('admin')->name('admin.')->middleware(['auth'])->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/quick-stats', [DashboardController::class, 'getQuickStats'])->name('dashboard.quick-stats');
    Route::get('/dashboard/stats', [DashboardController::class, 'getQuickStats'])->name('dashboard.stats');
    Route::get('/dashboard/chart-data', [DashboardController::class, 'getChartData'])->name('dashboard.chart-data');

    // Categories
    Route::resource('categories', CategoryController::class);
    Route::patch('categories/{category}/status', [CategoryController::class, 'updateStatus'])->name('categories.updateStatus');

    // Bulk Actions
    Route::post('categories/bulk-activate', [CategoryController::class, 'bulkActivate'])->name('categories.bulk-activate');
    Route::post('categories/bulk-deactivate', [CategoryController::class, 'bulkDeactivate'])->name('categories.bulk-deactivate');
    Route::delete('categories/bulk-delete', [CategoryController::class, 'bulkDelete'])->name('categories.bulk-delete');

    // Import/Export
    Route::post('categories/import', [CategoryController::class, 'import'])->name('categories.import');
    Route::get('categories/export', [CategoryController::class, 'export'])->name('categories.export');

    // Jobs
    Route::resource('jobs', AdminJobController::class);
    Route::patch('jobs/{job}/status', [AdminJobController::class, 'updateStatus'])->name('jobs.updateStatus');

    // Results
    Route::resource('results', AdminResultController::class);
    Route::patch('results/{result}/status', [AdminResultController::class, 'updateStatus'])->name('results.updateStatus');

    // Admit Cards
    Route::resource('admit-cards', AdminAdmitCardController::class);
    Route::patch('admit-cards/{admitCard}/status', [AdminAdmitCardController::class, 'updateStatus'])->name('admit-cards.updateStatus');
    Route::get('admit-cards/{admitCard}/download', [AdminAdmitCardController::class, 'downloadFile'])->name('admit-cards.download');

    // Answer Keys
    Route::resource('answer-keys', AdminAnswerKeyController::class);
    Route::patch('answer-keys/{answerKey}/status', [AdminAnswerKeyController::class, 'updateStatus'])->name('answer-keys.update-status');
    Route::get('answer-keys/{answerKey}/download', [AdminAnswerKeyController::class, 'downloadFile'])->name('answer-keys.download');

    // Admissions
    Route::get('/admissions', [AdminAdmissionController::class, 'index'])->name('admissions.index');
    Route::get('/admissions/create', [AdminAdmissionController::class, 'create'])->name('admissions.create');
    Route::post('/admissions', [AdminAdmissionController::class, 'store'])->name('admissions.store');
    Route::get('/admissions/{admission}/edit', [AdminAdmissionController::class, 'edit'])->name('admissions.edit');
    Route::put('/admissions/{admission}', [AdminAdmissionController::class, 'update'])->name('admissions.update');
    Route::delete('/admissions/{admission}', [AdminAdmissionController::class, 'destroy'])->name('admissions.destroy');
    Route::post('/admissions/{admission}/toggle-status', [AdminAdmissionController::class, 'toggleStatus'])->name('admissions.toggle-status');
    Route::post('/admissions/{admission}/toggle-featured', [AdminAdmissionController::class, 'toggleFeatured'])->name('admissions.toggle-featured');
    Route::post('/admissions/bulk-action', [AdminAdmissionController::class, 'bulkAction'])->name('admissions.bulk-action');

    // Universities Management
    Route::get('/universities', [AdminUniversityController::class, 'index'])->name('universities.index');
    Route::get('/universities/create', [AdminUniversityController::class, 'create'])->name('universities.create');
    Route::post('/universities', [AdminUniversityController::class, 'store'])->name('universities.store');
    Route::get('/universities/{university}/edit', [AdminUniversityController::class, 'edit'])->name('universities.edit');
    Route::put('/universities/{university}', [AdminUniversityController::class, 'update'])->name('universities.update');
    Route::delete('/universities/{university}', [AdminUniversityController::class, 'destroy'])->name('universities.destroy');
    Route::post('/universities/{university}/toggle-status', [AdminUniversityController::class, 'toggleStatus'])->name('universities.toggle-status');

    // Courses Management
    Route::get('/courses', [CourseController::class, 'index'])->name('courses.index');
    Route::get('/courses/create', [CourseController::class, 'create'])->name('courses.create');
    Route::post('/courses', [CourseController::class, 'store'])->name('courses.store');
    Route::get('/courses/{course}/edit', [CourseController::class, 'edit'])->name('courses.edit');
    Route::put('/courses/{course}', [CourseController::class, 'update'])->name('courses.update');
    Route::delete('/courses/{course}', [CourseController::class, 'destroy'])->name('courses.destroy');
    Route::post('/courses/{course}/toggle-status', [CourseController::class, 'toggleStatus'])->name('courses.toggle-status');
    
    // Documents Management
    Route::resource('documents', AdminDocumentController::class);
    Route::post('/documents/{document}/toggle-status', [AdminDocumentController::class, 'toggleStatus'])->name('documents.toggle-status');
    Route::post('/documents/{document}/toggle-featured', [AdminDocumentController::class, 'toggleFeatured'])->name('documents.toggle-featured');
    Route::post('/documents/bulk-delete', [AdminDocumentController::class, 'bulkDelete'])->name('documents.bulk-delete');
    Route::get('/documents/export/csv', [AdminDocumentController::class, 'export'])->name('documents.export');
});

// Auth Routes
Auth::routes();

// Storage Route - FIXED: Use correct parameter binding
Route::get('/storage/{path}', function ($path) {
    $fullPath = storage_path('app/public/' . $path);
    
    if (!file_exists($fullPath)) {
        abort(404);
    }
    
    return response()->file($fullPath);
})->where('path', '.*');

// Fallback Route - Must be LAST
Route::fallback(function () {
    return response()->view('errors.404', [], 404);
});